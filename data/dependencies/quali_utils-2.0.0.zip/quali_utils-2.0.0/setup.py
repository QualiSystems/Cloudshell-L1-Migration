﻿from distutils.core import setup

setup(
    name='quali_utils',
    url='http://www.qualisystems.com/',
    author='QualiSystems',
    author_email='info@qualisystems.com',
    packages=['quali_utils'],
    package_dir={'quali_utils': '.'},
    package_data={'quali_utils': ['QualiSystems.Packaging.exe']},
    version='2.0.0',
    description='QualiSystems quali-packaging package'
)