﻿"""
Quali packaging API provides an automated way of creating CloudShell packages. 
A package is a zip file that includes a set of folders and files that represent CloudShell elements, these can be
imported easily into the CloudShell database from the web portal or by calling the Quali REST API. The packaging API
helps creating new CloudShell packages or modifying existing packages. 
"""
from subprocess import *
import os.path
import json
import pickle
from json import dumps, loads, JSONEncoder, JSONDecoder
import jsonpickle


class PackageEditor(object):
    def __init__(self):
        self.packagePath = None
        self.process = _PackageProcess()

    def _validate_called_load(self):
        if self.packagePath is None:
            raise Exception("PackageEditor.load has to be called before any other method "
                            "(if the method is PackageEditor.create, call load afterwards).")

    def load(self, path):
        """Load existing package that the package editor is going to modify"""
        self.packagePath = path

    def create(self, path):
        """Create a new empty package in the specified path"""
        self.packagePath = path
        self._executeMethod("create")
        self.packagePath = None

    def get_topology_names(self):
        """Retrieve the list of environments in the loaded package"""
        self._validate_called_load()
        return self._executeMethod("GetTopologyNames").split('\n')

    def get_topology_xml(self, topology_name):
        """Gets the environment details of the specified environment as an xml """
        self._validate_called_load()
        return self._executeMethod("GetTopologyXml", "/topologyname ", topology_name)

    def add_visual_connector(self, topology_name, connector_alias, resource_source_name, resource_target_name,
                             source_family_type, target_family_type, direction):
        """Add a visual connector between the source and target resources in the specified environment"""
        self._validate_called_load()
        self._executeMethod("AddVisualConnector",
                            "/topologyname", topology_name,
                            "/connectoralias", connector_alias,
                            "/resourcesourcename", resource_source_name,
                            "/resourcetargetname", resource_target_name,
                            "/sourcefamilytype", source_family_type,
                            "/targetfamilytype", target_family_type,
                            "/direction", direction)
    
    def remove_global_input(self, topology_name, global_input_name):
        """Remove global input from given environment"""
        self._validate_called_load()
        self._executeMethod("RemoveGlobalInput",
                            "/topologyname", topology_name,
                            "/globalinputname", global_input_name)

    def remove_visual_connector_by_alias(self, topology_name, connector_alias):
        """Remove the visual connector with the specified alias from the environment"""
        self._validate_called_load()
        self._executeMethod("RemoveVisualConnectorByAlias",
                            "/topologyname", topology_name,
                            "/connectoralias", connector_alias)

    def remove_visual_connector_by_endpoints(self, topology_name, source, target, direction):
        """Remove the visual connector between the specified source and target resources from the environment"""
        self._validate_called_load()
        self._executeMethod("RemoveVisualConnectorByEndpoints",
                            "/topologyname", topology_name,
                            "/source", source,
                            "/target", target,
                            "/direction", direction)

    def set_visual_connector_attribute(self, topology_name, connector_alias, attribute_name, attribute_value):
        """Update the attribute value of the visual connector that has the specified alias"""
        self._validate_called_load()
        self._executeMethod("SetVisualConnectorAttribute",
                            "/topologyname", topology_name,
                            "/connectoralias", connector_alias,
                            "/attributename", attribute_name,
                            "/attributevalue", attribute_value)

    def add_family(self, family_name, description, categories, connectable, admin_only, shared_by_default,
                   service_family, searchable):
        """Add a new family"""
        self._validate_called_load()
        self._executeMethod("AddFamily",
                            "/familyname", family_name,
                            "/description", description,
                            "/categories", categories,
                            "/connectable", connectable,
                            "/adminonly", admin_only,
                            "/sharedbydefault", shared_by_default,
                            "/servicefamily", service_family,
                            "/searchable", searchable)

    def attach_attribute_to_family(self, family_name, attribute_name, user_input, allowed_values):
        """Attach existing attribute to a family"""
        self._validate_called_load()
        self._executeMethod("AttachAttributeToFamily",
                            "/familyname", family_name,
                            "/attributename", attribute_name,
                            "/userinput", user_input,
                            "/allowedvalues", allowed_values)

    def add_model_to_family(self, family_name, model_name, description):
        """Create a new model under the specified family"""
        self._validate_called_load()
        self._executeMethod("AddModelToFamily",
                            "/familyname", family_name,
                            "/modelname", model_name,
                            "/description", description)

    def attach_attribute_to_model(self, model_name, attribute_name, user_input, allowed_values):
        """Attach existing attribute to a model"""
        self._validate_called_load()
        self._executeMethod("AttachAttributeToModel",
                            "/modelname", model_name,
                            "/attributename", attribute_name,
                            "/userinput", user_input,
                            "/allowedvalues", allowed_values)

    def add_parent_model(self, model_name, parent_models):
        """Create the model hierarchy, link the specified model under the list of parent models"""
        self._validate_called_load()
        self._executeMethod("AddParentModel",
                            "/modelname", model_name,
                            "/parentmodels", parent_models)

    def remove_parent_model(self, model_name, parent_models):
        """Modify model hierarchy, remove the specified model from the list of parent models"""
        self._validate_called_load()
        self._executeMethod("RemoveParentModel",
                            "/modelname", model_name,
                            "/parentmodels", parent_models)

    def add_or_update_attribute(self, attribute_name, default_value, description, attribute_type, lookup_values, rules):
        """Add a new attribute, or modify existing attribute"""
        self._validate_called_load()
        self._executeMethod("AddOrUpdateAttribute",
                            "/attributename", attribute_name,
                            "/defaultvalue", default_value,
                            "/description", description,
                            "/attributetype", attribute_type,
                            "/lookupvalues", lookup_values,
                            "/rules ", rules)

    def add_route(self, topology_name, route_alias, source, target, route_interface, max_hops, direction, shared):
        """Create a route between the source and target resources in the specified environment"""
        self._validate_called_load()
        self._executeMethod("AddRoute",
                            "/topologyname", topology_name,
                            "/routealias", route_alias,
                            "/source", source,
                            "/target", target,
                            "/routeInterface", route_interface,
                            "/maxhops", max_hops,
                            "/direction", direction,
                            "/shared", shared)

    def remove_route_by_alias(self, topology_name, route_alias):
        """Remove the existing route that has the specified alias from the environment"""
        self._validate_called_load()
        self._executeMethod("RemoveRouteByAlias",
                            "/topologyname", topology_name,
                            "/routealias", route_alias)

    def remove_route_by_endpoints(self, topology_name, source, target, direction):
        """Remove the existing route that connects the source and target resources from the environment"""
        self._validate_called_load()
        self._executeMethod("RemoveRouteByEndpoints",
                            "/topologyname", topology_name,
                            "/source", source,
                            "/target", target,
                            "/direction", direction)

    def set_route_attribute(self, topology_name, route_alias, attribute_name, target, attribute_value):
        """Set the attribute value of the route attribute which is specified by the route alias and attribute name
        (Target: All, Source, Target)"""
        self._validate_called_load()
        self._executeMethod("SetRouteAttribute",
                            "/topologyname", topology_name,
                            "/routealias", route_alias,
                            "/attributename", attribute_name,
                            "/target", target,
                            "/attributevalue", attribute_value)

    def change_topology_name_and_alias(self, topology_name, new_name):
        """Update the name and alias of the specified topology"""
        self._validate_called_load()
        self._executeMethod("ChangeTopologyNameAndAlias",
                            "/topologyname", topology_name,
                            "/newname", new_name)

    def add_global_input_to_topology(self, topology_name, globalInputName, inputType, defaultValue, description,
                                     possibleValues):
        """Add environment global input"""
        self._validate_called_load()
        self._executeMethod("AddGlobalInputToTopology",
                            "/topologyname", topology_name,
                            "/globalInputName", globalInputName,
                            "/inputType", inputType,
                            "/defaultValue", defaultValue,
                            "/description", description,
                            "/possibleValues", possibleValues)

    def add_resource_to_topology(self, topology_name, resource_full_name, is_shared=True, position_x=200,
                                 position_y=200):
        """Add a new resource to the environment"""
        self._validate_called_load()
        self._executeMethod("AddResourceToTopology",
                            "/topologyname", topology_name,
                            "/resourcefullname", resource_full_name,
                            "/isshared", is_shared,
                            "/positionx", position_x,
                            "/positiony", position_y)

    def remove_resource_from_topology(self, topology_name, resource_full_name):
        """Remove existing resource from the environment """
        self._validate_called_load()
        self._executeMethod("RemoveResourceFromTopology",
                            "/topologyname", topology_name,
                            "/resourcefullname", resource_full_name)

    def set_default_start_time(self, topology_name, start_time):
        """Update the default start time for the topology"""
        self._validate_called_load()
        self._executeMethod("SetDefaultStartTime",
                            "/topologyname", topology_name,
                            "/starttime", start_time)

    def set_default_duration(self, topology_name, duration):
        """Set the default duration for the topology"""
        self._validate_called_load()
        self._executeMethod("SetDefaultDuration",
                            "/topologyname", topology_name,
                            "/duration", duration)

    def set_default_user(self, topology_name, username):
        """Set the default duration for the topology"""
        self._validate_called_load()
        self._executeMethod("SetDefaultUser",
                            "/topologyname", topology_name,
                            "/username", username)

    def add_driver_to_model(self, model_name, driver_name, driver_file_path):
        """Add a driver to the specified model"""
        self._validate_called_load()
        self._executeMethod("AddDriverToModel",
                            "/modelname", model_name,
                            "/drivername", driver_name,
                            "/driverfilepath", driver_file_path)

    def remove_driver_from_model(self, model_name, driver_name):
        """Remove the driver from the specified model"""
        self._validate_called_load()
        self._executeMethod("RemoveDriverFromModel",
                            "/modelname", model_name,
                            "/drivername", driver_name)

    def add_topology(self, topology_name, is_public, image_file_path, default_duration, instructions,
                     categories, diagram_zoom):
        """Add a new topology to the package"""
        self._validate_called_load()
        self._executeMethod("AddTopology",
                            "/topologyname", topology_name,
                            "/ispublic", is_public,
                            "/imagefilepath", image_file_path,
                            "/defaultduration", default_duration,
                            "/instructions", instructions,
                            "/categories", categories,
                            "/diagramzoom", diagram_zoom)

    def remove_topology(self, topology_name):
        """Remove an existing topology from the package"""
        self._validate_called_load()
        self._executeMethod("RemoveTopology",
                            "/topologyname", topology_name)

    def add_service_to_topology(self, topology_name, service_name, alias, position_x, position_y):
        """Add a service to the topology"""
        self._validate_called_load()
        self._executeMethod("AddServiceToTopology",
                            "/topologyname", topology_name,
                            "/servicename", service_name,
                            "/alias", alias,
                            "/positionx", position_x,
                            "/positiony", position_y)

    def remove_service_from_topology(self, topology_name, service_alias):
        """Removes an existing service from the specified topology"""
        self._validate_called_load()
        self._executeMethod("RemoveServiceFromTopology",
                            "/topologyname", topology_name,
                            "/servicealias", service_alias)

    def add_abstract_to_topology(self, topology_name, abstract_path, is_shared, position_x, position_y,
            family, models, default_model, publish_models, quantity, publish_quantity):
        """Add an abstract resource / template to the specified topology"""
        self._validate_called_load()
        self._executeMethod("AddAbstractToTopology",
                            "/topologyname", topology_name,
                            "/abstractpath", abstract_path,
                            "/isshared", is_shared,
                            "/positionx", position_x,
                            "/positiony", position_y,
                            "/family", family,
                            "/models", models,
                            "/defaultmodel", default_model,
                            "/publishmodels", publish_models,
                            "/quantity", quantity,
                            "/publishquantity", publish_quantity)

    def remove_abstract_from_topology(self, topology_name, abstract_path):
        """Remove the abstract resource / template from the specified topology"""
        self._validate_called_load()
        self._executeMethod("RemoveAbstractFromTopology",
                            "/topologyname", topology_name,
                            "/abstractpath", abstract_path)

    def add_attribute_to_abstract(self, topology_name, abstract_path, attribute_name, possible_values, default_value, required, publish):
        """Add a new attribute to the specified abstract resource"""
        self._validate_called_load()
        self._executeMethod("AddAttributeToAbstract",
                            "/topologyname", topology_name,
                            "/abstractpath", abstract_path,
                            "/attributename", attribute_name,
                            "/possiblevalues", possible_values,
                            "/defaultvalue", default_value,
                            "/required", required,
                            "/publish", publish)

    def remove_attribute_from_abstract(self, topology_name, abstract_path, attribute_name, required):
        """Remove existing attribute from the specified abstract resource"""
        self._validate_called_load()
        self._executeMethod("RemoveAttributeFromAbstract",
                            "/topologyname", topology_name,
                            "/abstractpath", abstract_path,
                            "/attributename", attribute_name,
                            "/required", required)

    def add_driver_to_topology(self, topology_name, driver_name, driver_file_path):
        """Add a driver to an existing environment"""
        self._validate_called_load()
        self._executeMethod("AddDriverToTopology",
                            "/topologyname", topology_name,
                            "/drivername", driver_name,
                            "/driverfilepath", driver_file_path)
    
    def set_setup_duration(self, topology_name, minutes):
        """Sets the setup duration time for the specified environment"""
        self._validate_called_load()
        self._executeMethod("SetSetupDuration",
                            "/topologyname", topology_name,
                            "/minutes", minutes)

    def set_teardown_duration(self, topology_name, minutes):
        """Sets the teardown duration time for the specified environment"""
        self._validate_called_load()
        self._executeMethod("SetTeardownDuration",
                            "/topologyname", topology_name,
                            "/minutes", minutes)

    def set_max_duration(self, topology_name, minutes):
        """Sets the max duration time for the specified environment"""
        self._validate_called_load()
        self._executeMethod("SetMaxDuration",
                            "/topologyname", topology_name,
                            "/minutes", minutes)

    def add_script_to_model(self, model_name, script_name, script_file_path, version, script_alias, parameters, category):
        """Add a script to the specified model"""
        self._validate_called_load()
        self._executeMethod("AddScriptToModel",
                            "/modelname", model_name,
                            "/scriptname", script_name,
                            "/scriptfilepath", script_file_path,
                            "/version", version,
                            "/scriptalias", script_alias,
                            "/parameters", parameters,
                            "/category", category)

    def remove_script_from_model(self, model_name, script_name):
        """Remove the script from the specified model"""
        self._validate_called_load()
        self._executeMethod("RemoveScriptFromModel",
                            "/modelname", model_name,
                            "/scriptname", script_name)

    def add_script_to_topology(self, topology_name, script_name, script_file_path, version, script_alias, parameters, category):
        """Add a script to an existing environment"""
        self._validate_called_load()
        self._executeMethod("AddScriptToTopology",
                            "/topologyname", topology_name,
                            "/scriptname", script_name,
                            "/scriptfilepath", script_file_path,
                            "/version", version,
                            "/scriptalias", script_alias,
                            "/parameters", parameters,
                            "/category", category)

    def add_app(self, topology_name, topology_app):
        """Adds an app to an exisiting environment"""
        self._validate_called_load()
        topology_app_json = self.arrange_json(self.convert_topology_app_to_json(topology_app))
        self._executeMethod("AddApp",
                            "/topologyname", topology_name,
                            "/topologyappjson", topology_app_json)

    def edit_app(self, topology_name, app_name, topology_app):
        """Edits an app to an exisiting environment"""
        self._validate_called_load()
        topology_app_json = self.arrange_json(self.convert_topology_app_to_json(topology_app))
        self._executeMethod("EditApp",
                            "/topologyname", topology_name,
                            "/appname", app_name,
                            "/topologyappjson", topology_app_json)

    def get_apps(self, topology_name):
        """Gets apps from an exisiting environment"""
        self._validate_called_load()
        apps_json = self._executeMethod("GetApps", "/topologyname", topology_name)
        dicts = self.convert_json_to_topology_app(apps_json)
        return dicts

    def arrange_json(self, topology_app_json):
        return topology_app_json.replace('"', '\\"')    

    def _executeMethod(self, method, *parameters):
        return self.process.execute(method, "/packagepath", self.packagePath, *parameters)

    def convert_topology_app_to_json(self, topology_app):
        dict = topology_app.__dict__
        return jsonpickle.encode(topology_app)
        # return json.dumps(topology_app, cls=PythonObjectEncoder)

    def convert_json_to_topology_app(self, topology_app_json):
        result = []

        apps = json.loads(topology_app_json)
        if not apps:
            return result

        for app in apps:    
            topology_app = TopologyApp()
            topology_app.templateName = app["templateName"]
            topology_app.positionX = app["positionX"]
            topology_app.positionY = app["positionY"]

            appResource = AppResource()     
            appResource.name = app["appResource"]["name"]
            appResource.description = app["appResource"]["description"]
            appResource.imagePath = app["appResource"]["imagePath"]
            
            logicalResource = AppResourceInner()
            logicalResource.modelName = app["appResource"]["logicalResource"]["modelName"]
            logicalResource.driver = app["appResource"]["logicalResource"]["driver"]
            logicalResourceAttributes = []
            for attr in app["appResource"]["logicalResource"]["attributes"]:
                logicalResourceAttributes.append(AttributeValue(attr["name"], attr["value"]))
            logicalResource.attributes = logicalResourceAttributes

            deploymentPaths = []
            for deploymentPath in app["appResource"]["deploymentPaths"]:

                deploymentService = DeploymentService()   
                deploymentService.name = deploymentPath["deploymentService"]["name"]
                deploymentService.cloudProvider = deploymentPath["deploymentService"]["cloudProvider"]
                deploymentServiceAttributes = []
                if deploymentPath["deploymentService"]["attributes"] is not None:
                    for attr in deploymentPath["deploymentService"]["attributes"]:
                        deploymentServiceAttributes.append(AttributeValue(attr["name"], attr["value"]))
                deploymentService.attributes = deploymentServiceAttributes                

                depPath = DeploymentPath()
                depPath.name = deploymentPath["name"]
                depPath.default = deploymentPath["default"]
                depPath.deploymentService = deploymentService

                deploymentPaths.append(depPath)

            cm = ConfigurationManagement()
            cm_json = app["appResource"]["configurationManagement"]
            if cm_json["ansible"] is not None:
                ansible_cm = AnsibleConfigurationManagement()
                ansible_cm_json = cm_json["ansible"]
                ansible_cm.inventoryGroups = ansible_cm_json["inventoryGroups"]
                ansible_cm.connectionMethod = ansible_cm_json["connectionMethod"]
                ansible_cm.overrideParameters = ansible_cm_json["overrideParameters"]
                ansible_repo_json = ansible_cm_json["repository"]
                if ansible_repo_json is not None:
                    ansible_cm.repository = HttpSimpleRepository(ansible_repo_json["url"], ansible_repo_json["userName"], ansible_repo_json["password"])

                params = []
                if ansible_cm_json["parameters"] is not None:
                    for param in ansible_cm_json["parameters"]:
                        params.append(ConfigurationManagementParameter(param["name"], param["value"]))
                    ansible_cm.parameters = params
                cm.ansible = ansible_cm

            if cm_json["customScript"] is not None:
                script_cm = CustomScriptConfigurationManagement()
                script_cm_json = cm_json["customScript"]
                script_cm.connectionMethod = script_cm_json["connectionMethod"]
                script_cm.overrideParameters = script_cm_json["overrideParameters"]
                script_repo_json = script_cm_json["repository"]
                if script_repo_json is not None:
                    script_cm.repository = HttpSimpleRepository(script_repo_json["url"], script_repo_json["userName"],script_repo_json["password"])

                params = []
                if script_cm_json["parameters"] is not None:
                    for param in script_cm_json["parameters"]:
                        params.append(ConfigurationManagementParameter(param["name"], param["value"]))
                    script_cm.parameters = params
                cm.customScript = script_cm

            appResource.logicalResource = logicalResource
            appResource.deploymentPaths = deploymentPaths
            appResource.configurationManagement = cm

            topology_app.appResource = appResource
            result.append(topology_app)

        return result



class _PackageProcess(object):
    def __init__(self):
        self.exePath = os.path.join(os.path.dirname(__file__), "QualiSystems.Packaging.exe")

    def _flat_heirarchy(self, *args):
        strArgs = []
        for i, s in enumerate(args):
            if isinstance(s, list):
                strArgs.extend(self._flat_heirarchy(self, *tuple(s)))
            elif isinstance(s, tuple):
                strArgs.extend(self._flat_heirarchy(self, *s))
            elif isinstance(s, _PackageProcess):
                pass
            else:
                strArgs.append('"'+unicode(s).encode('UTF-8')+'"')
        return strArgs

    def execute(self, *args):
        strargs = self._flat_heirarchy(self, *args)
        strcmd = self.exePath + " " + " ".join(strargs)
        try:
            return check_output(strcmd, stderr=STDOUT, universal_newlines=True)
        except CalledProcessError as e:
            raise Exception(e.output)


class PythonObjectEncoder(JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (list, dict, str, unicode, int, float, bool, type(None))):
            return JSONEncoder.default(self, obj)
        return {'_python_object': pickle.dumps(obj)}

    def as_python_object(dct):
        if '_python_object' in dct:
            return pickle.loads(str(dct['_python_object']))
        return dct

class TopologyApp:
    def __init__(self):
        self.templateName = ''
        """:type : str"""
        self.positionX = 0
        """:type : double"""
        self.positionY = 0
        """:type : double"""
        self.appResource = ''
        """:type : AppResource"""


class AppResource:
    def __init__(self):
        self.name = ''
        """:type : str"""
        self.imagePath = ''
        """:type : str"""
        self.description = ''
        """:type : str"""
        self.logicalResource = ''
        """:type : AppResourceInner"""
        self.deploymentPaths = ''
        """:type : list[DeploymentPath]"""
        self.configurationManagement = ''
        """:type : ConfigurationManagement"""


class ConfigurationManagement:
    def __init__(self):
        self.ansible = ''
        """:type : AnsibleConfigurationManagement"""
        self.customScript = ''
        """:type : CustomScriptConfigurationManagement"""


class AnsibleConfigurationManagement:
    def __init__(self):
        self.repository = ''
        """:type : HttpSimpleRepository"""
        self.parameters = ''
        """:type : list[ConfigurationManagementParameter]"""
        self.connectionMethod = ''
        """:type : str"""
        self.inventoryGroups = ''
        """:type : str"""
        self.overrideParameters = ''
        """:type : bool"""


class CustomScriptConfigurationManagement:
    def __init__(self):
        self.repository = ''
        """:type : HttpSimpleRepository"""
        self.parameters = ''
        """:type : list[ConfigurationManagementParameter]"""
        self.connectionMethod = ''
        """:type : str"""
        self.overrideParameters = ''
        """:type : bool"""


class HttpSimpleRepository:
    def __init__(self, url, username, password):
        self.url = url
        """:type : str"""
        self.userName = username
        """:type : str"""
        self.password = password
        """:type : str"""


class ConfigurationManagementParameter:
    def __init__(self, name, value):
        self.name = name
        """:type : str"""
        self.value = value
        """:type : str"""


class AppResourceInner:
    def __init__(self):
        self.modelName = ''
        """:type : str"""
        self.driver = ''
        """:type : str"""
        self.attributes = ''
        """:type : list[AttributeValue]"""


class DeploymentPath:
    def __init__(self):
        self.name = ''
        """:type : str"""
        self.default = ''
        """:type : bool"""
        self.deploymentService = ''
        """:type : DeploymentService"""


class DeploymentService:
    def __init__(self):
        self.name = ''
        """:type : str"""
        self.attributes = ''
        """:type : AttributeValue"""
        self.cloudProvider =''
        """:type: str"""


class AttributeValue:
    def __init__(self, name, value):
        self.name = name
        """:type : str"""
        self.value = value
        """:type : str"""

